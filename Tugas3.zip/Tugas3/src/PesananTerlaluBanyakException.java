public class PesananTerlaluBanyakException extends Exception {
    public PesananTerlaluBanyakException(String message) {
        super(message);
    }
}