

public class Produk implements Pembayaran {
    private String noFaktur;
    private String namaPelanggan;
    private String noHpPelanggan;
    private String alamatPelanggan;
    private String namaBarang;
    private double hargaBarang;
    private int jumlahBarang;
    private String kasir;
    

    public Produk(String noFaktur, String namaPelanggan, String noHpPelanggan, String alamatPelanggan,
                  String namaBarang, double hargaBarang, int jumlahBarang, String kasir) {
        this.noFaktur = noFaktur;
        this.namaPelanggan = namaPelanggan;
        this.noHpPelanggan = noHpPelanggan;
        this.alamatPelanggan = alamatPelanggan;
        this.namaBarang = namaBarang;
        this.hargaBarang = hargaBarang;
        this.jumlahBarang = jumlahBarang;
        this.kasir = kasir;
    }

    @Override
    public double hitungTotalBayar() {
        return hargaBarang * jumlahBarang;
    }


    public String getNoFaktur() {
        return noFaktur;
    }

    public String getNamaPelanggan() {
        return namaPelanggan;
    }

    public String getNoHpPelanggan() {
        return noHpPelanggan;
    }

    public String getAlamatPelanggan() {
        return alamatPelanggan;
    }

    public String getNamaBarang() {
        return namaBarang;
    }

    public double getHargaBarang() {
        return hargaBarang;
    }

    public int getJumlahBarang() {
        return jumlahBarang;
    }

    public String getKasir() {
        return kasir;
    }
}