import java.util.Scanner;

public class Driver {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("No. Faktur: ");
            String noFaktur = scanner.nextLine();

            System.out.print("Nama Pelanggan: ");
            String namaPelanggan = scanner.nextLine();

            System.out.print("Nama Barang: ");
            String namaBarang = scanner.nextLine();

            System.out.print("Harga Barang: ");
            double hargaBarang = scanner.nextDouble();

            System.out.print("Jumlah Barang: ");
            int jumlahBarang = scanner.nextInt();

            if (jumlahBarang > 100000) {
                throw new PesananTerlaluBanyakException("Pesanan terlalu banyak");
            }

            Produk produk = new Produk(noFaktur, namaPelanggan, namaBarang, hargaBarang, jumlahBarang);

            System.out.println("\n------Detail Pesanan: ------");
            System.out.println("No. Faktur: " + produk.getNoFaktur());
            System.out.println("Nama Pelanggan: " + produk.getNamaPelanggan());
            System.out.println("Nama Barang: " + produk.getNamaBarang());
            System.out.println("Harga Barang: " + produk.getHargaBarang());
            System.out.println("Jumlah Barang: " + produk.getJumlahBarang());
            System.out.println("Total Bayar: " + produk.hitungTotalBayar());
        } catch (PesananTerlaluBanyakException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}
