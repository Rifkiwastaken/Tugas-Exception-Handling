public class Produk implements Pembayaran {
    private String noFaktur;
    private String namaPelanggan;
    private String namaBarang;
    private double hargaBarang;
    private int jumlahBarang;

    public Produk(String noFaktur, String namaPelanggan, String namaBarang, double hargaBarang, int jumlahBarang) {
        this.noFaktur = noFaktur;
        this.namaPelanggan = namaPelanggan;
        this.namaBarang = namaBarang;
        this.hargaBarang = hargaBarang;
        this.jumlahBarang = jumlahBarang;
    }

    // Interface dan polymorphism
    @Override
    public double hitungTotalBayar() {
        return hargaBarang * jumlahBarang;
    }

    // Getter dan setter lainnya

    public String getNoFaktur() {
        return noFaktur;
    }

    public String getNamaPelanggan() {
        return namaPelanggan;
    }

    public String getNamaBarang() {
        return namaBarang;
    }

    public double getHargaBarang() {
        return hargaBarang;
    }

    public int getJumlahBarang() {
        return jumlahBarang;
    }
}
