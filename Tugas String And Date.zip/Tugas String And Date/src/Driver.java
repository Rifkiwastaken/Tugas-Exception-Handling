import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Driver {
    public static void main(String[] args) {

        Date HariSekarang = new Date();
        SimpleDateFormat ft =
        new SimpleDateFormat ("E yyyy.MM.dd");
        Scanner scanner = new Scanner(System.in);

        Date date = new Date();
        SimpleDateFormat format = new SimpleDateFormat("hh:mm:ss");
        String formattedTime = format.format(date);

        try {
            System.out.print("No. Faktur: ");
            String noFaktur = scanner.nextLine();

            System.out.print("Nama Pelanggan: ");
            String namaPelanggan = scanner.nextLine();

            System.out.print("No. HP Pelanggan: ");
            String noHpPelanggan = scanner.nextLine();

            System.out.print("Alamat Pelanggan: ");
            String alamatPelanggan = scanner.nextLine();

            System.out.print("Nama Barang: ");
            String namaBarang = scanner.nextLine();

            System.out.print("Harga Barang: ");
            double hargaBarang = scanner.nextDouble();

            System.out.print("Jumlah Barang: ");
            int jumlahBarang = scanner.nextInt();

            System.out.print("Nama Kasir: ");
            String kasir = scanner.next();

            if (jumlahBarang > 1000000000) {
                throw new PesananTerlaluBanyakException("Pesanan terlalu banyak, tidak dapat dikalkulasikan");
            }

            Produk produk = new Produk(noFaktur, namaPelanggan, noHpPelanggan, alamatPelanggan,
                    namaBarang, hargaBarang, jumlahBarang, kasir);

            System.out.println("\n========================");
            System.out.println("Supermarket Berkah");
            System.out.println("Tanggal : " + ft.format(HariSekarang));
            System.out.println("Waktu   : " + formattedTime);
            System.out.println("========================");
            System.out.println("DATA PELANGGAN");
            System.out.println("---------------------");
            System.out.println("Nama Pelanggan : " + produk.getNamaPelanggan());
            System.out.println("No. HP         : " + produk.getNoHpPelanggan());
            System.out.println("Alamat         : " + produk.getAlamatPelanggan());
            System.out.println("++++++++++++++++++++++++");
            System.out.println("DATA PEMBELIAN BARANG");
            System.out.println("------------------------------");
            System.out.println("Kode Barang    : " + produk.getNoFaktur());
            System.out.println("Nama Barang    : " + produk.getNamaBarang());
            System.out.println("Harga Barang   : " + produk.getHargaBarang());
            System.out.println("Jumlah Beli    : " + produk.getJumlahBarang());
            System.out.println("TOTAL BAYAR    : " + produk.hitungTotalBayar());
            System.out.println("++++++++++++++++++++++++");
            System.out.println("Kasir          : " + produk.getKasir());
        } catch (PesananTerlaluBanyakException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}