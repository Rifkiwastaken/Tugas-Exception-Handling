import java.util.Scanner;

public class Driver {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("No. Faktur: ");
            String noFaktur = scanner.nextLine();

            Produk produk = Produk.readFromDatabase(noFaktur);

            if (produk == null) {
                // Data tidak ditemukan, lakukan operasi create
                System.out.print("Nama Pelanggan: ");
                String namaPelanggan = scanner.nextLine();

                System.out.print("No. HP Pelanggan: ");
                String noHpPelanggan = scanner.nextLine();

                System.out.print("Alamat Pelanggan: ");
                String alamatPelanggan = scanner.nextLine();

                System.out.print("Nama Barang: ");
                String namaBarang = scanner.nextLine();

                System.out.print("Harga Barang: ");
                double hargaBarang = scanner.nextDouble();

                System.out.print("Jumlah Barang: ");
                int jumlahBarang = scanner.nextInt();

                System.out.print("Nama Kasir: ");
                String kasir = scanner.next();

                produk = new Produk(noFaktur, namaPelanggan, noHpPelanggan, alamatPelanggan,
                        namaBarang, hargaBarang, jumlahBarang, kasir);

                produk.insertToDatabase();
                System.out.println("Data berhasil ditambahkan ke database.");
            } else {
                // Data ditemukan, lakukan operasi update atau delete
                System.out.println("Data ditemukan:\n" +
                        "No. Faktur: " + produk.getNoFaktur() +
                        "\nNama Pelanggan: " + produk.getNamaPelanggan() +
                        "\nNo. HP Pelanggan: " + produk.getNoHpPelanggan() +
                        "\nAlamat Pelanggan: " + produk.getAlamatPelanggan() +
                        "\nNama Barang: " + produk.getNamaBarang() +
                        "\nHarga Barang: " + produk.getHargaBarang() +
                        "\nJumlah Barang: " + produk.getJumlahBarang() +
                        "\nKasir: " + produk.getKasir() +
                        "\nTanggal Pemesanan: " + produk.getTanggalPemesanan() +
                        "\nWaktu Pemesanan: " + produk.getWaktuPemesanan() +
                        "\nTotal Bayar: " + produk.hitungTotalBayar());

                System.out.println("Pilih operasi:\n1. Update data\n2. Hapus data");
                int choice = scanner.nextInt();

                if (choice == 1) {
                    // Lakukan operasi update
                    System.out.print("Nama Pelanggan (Enter jika tidak diubah): ");
                    String newNamaPelanggan = scanner.nextLine(); // membaca newline
                    newNamaPelanggan = scanner.nextLine();

                    System.out.print("No. HP Pelanggan (Enter jika tidak diubah): ");
                    String newNoHpPelanggan = scanner.nextLine();

                    System.out.print("Alamat Pelanggan (Enter jika tidak diubah): ");
                    String newAlamatPelanggan = scanner.nextLine();

                    System.out.print("Nama Barang (Enter jika tidak diubah): ");
                    String newNamaBarang = scanner.nextLine();

                    System.out.print("Harga Barang (Enter jika tidak diubah): ");
                    String newHargaBarangStr = scanner.nextLine();
                    double newHargaBarang = newHargaBarangStr.isEmpty() ? produk.getHargaBarang() : Double.parseDouble(newHargaBarangStr);

                    System.out.print("Jumlah Barang (Enter jika tidak diubah): ");
                    String newJumlahBarangStr = scanner.nextLine();
                    int newJumlahBarang = newJumlahBarangStr.isEmpty() ? produk.getJumlahBarang() : Integer.parseInt(newJumlahBarangStr);

                    System.out.print("Nama Kasir (Enter jika tidak diubah): ");
                    String newKasir = scanner.nextLine();

                    // Update hanya dilakukan jika pengguna memasukkan nilai yang baru
                    if (!newNamaPelanggan.isEmpty()) produk.setNamaPelanggan(newNamaPelanggan);
                    if (!newNoHpPelanggan.isEmpty()) produk.setNoHpPelanggan(newNoHpPelanggan);
                    if (!newAlamatPelanggan.isEmpty()) produk.setAlamatPelanggan(newAlamatPelanggan);
                    if (!newNamaBarang.isEmpty()) produk.setNamaBarang(newNamaBarang);
                    if (newHargaBarang != produk.getHargaBarang()) produk.setHargaBarang(newHargaBarang);
                    if (newJumlahBarang != produk.getJumlahBarang()) produk.setJumlahBarang(newJumlahBarang);
                    if (!newKasir.isEmpty()) produk.setKasir(newKasir);

                    produk.updateInDatabase();
                    System.out.println("Data berhasil diperbarui di database.");
                } else if (choice == 2) {
                    // Lakukan operasi delete
                    produk.deleteFromDatabase();
                    System.out.println("Data berhasil dihapus dari database.");
                }
            }

        } catch (PesananTerlaluBanyakException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}
