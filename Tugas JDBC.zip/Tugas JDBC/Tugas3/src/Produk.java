public class Produk implements Pembayaran {
    private String noFaktur;
    private String namaPelanggan;
    private String noHpPelanggan;
    private String alamatPelanggan;
    private String namaBarang;
    private double hargaBarang;
    private int jumlahBarang;
    private String kasir;
    

    public Produk(String noFaktur, String namaPelanggan, String noHpPelanggan, String alamatPelanggan,
                  String namaBarang, double hargaBarang, int jumlahBarang, String kasir) {
        this.noFaktur = noFaktur;
        this.namaPelanggan = namaPelanggan;
        this.noHpPelanggan = noHpPelanggan;
        this.alamatPelanggan = alamatPelanggan;
        this.namaBarang = namaBarang;
        this.hargaBarang = hargaBarang;
        this.jumlahBarang = jumlahBarang;
        this.kasir = kasir;
    }

    @Override
    public double hitungTotalBayar() {
        return hargaBarang * jumlahBarang;
    }


    public String getNoFaktur() {
        return noFaktur;
    }

    public String getNamaPelanggan() {
        return namaPelanggan;
    }

    public String getNoHpPelanggan() {
        return noHpPelanggan;
    }

    public String getAlamatPelanggan() {
        return alamatPelanggan;
    }

    public String getNamaBarang() {
        return namaBarang;
    }

    public double getHargaBarang() {
        return hargaBarang;
    }

    public int getJumlahBarang() {
        return jumlahBarang;
    }

    public String getKasir() {
        return kasir;

    // Metode CRUD

    public void insertToDatabase() {
        try (Connection connection = DriverManager.getConnection(JDBC_URL);
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "INSERT INTO produk VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {

            preparedStatement.setString(1, noFaktur);
            preparedStatement.setString(2, namaPelanggan);
            preparedStatement.setString(3, noHpPelanggan);
            preparedStatement.setString(4, alamatPelanggan);
            preparedStatement.setString(5, namaBarang);
            preparedStatement.setDouble(6, hargaBarang);
            preparedStatement.setInt(7, jumlahBarang);
            preparedStatement.setString(8, kasir);
            preparedStatement.setDate(9, tanggalPemesanan);
            preparedStatement.setTime(10, waktuPemesanan);

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static Produk readFromDatabase(String noFaktur) {
        Produk produk = null;

        try (Connection connection = DriverManager.getConnection(JDBC_URL);
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "SELECT * FROM produk WHERE no_faktur = ?")) {

            preparedStatement.setString(1, noFaktur);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    produk = new Produk(
                            resultSet.getString("no_faktur"),
                            resultSet.getString("nama_pelanggan"),
                            resultSet.getString("no_hp_pelanggan"),
                            resultSet.getString("alamat_pelanggan"),
                            resultSet.getString("nama_barang"),
                            resultSet.getDouble("harga_barang"),
                            resultSet.getInt("jumlah_barang"),
                            resultSet.getString("kasir")
                    );
                    produk.tanggalPemesanan = resultSet.getDate("tanggal_pemesanan");
                    produk.waktuPemesanan = resultSet.getTime("waktu_pemesanan");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return produk;
    }

    public void updateInDatabase() {
        try (Connection connection = DriverManager.getConnection(JDBC_URL);
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "UPDATE produk SET nama_pelanggan=?, no_hp_pelanggan=?, alamat_pelanggan=?, " +
                             "nama_barang=?, harga_barang=?, jumlah_barang=?, kasir=?, " +
                             "tanggal_pemesanan=?, waktu_pemesanan=? WHERE no_faktur=?")) {

            preparedStatement.setString(1, namaPelanggan);
            preparedStatement.setString(2, noHpPelanggan);
            preparedStatement.setString(3, alamatPelanggan);
            preparedStatement.setString(4, namaBarang);
            preparedStatement.setDouble(5, hargaBarang);
            preparedStatement.setInt(6, jumlahBarang);
            preparedStatement.setString(7, kasir);
            preparedStatement.setDate(8, tanggalPemesanan);
            preparedStatement.setTime(9, waktuPemesanan);
            preparedStatement.setString(10, noFaktur);

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteFromDatabase() {
        try (Connection connection = DriverManager.getConnection(JDBC_URL);
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "DELETE FROM produk WHERE no_faktur=?")) {

            preparedStatement.setString(1, noFaktur);

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    }
}