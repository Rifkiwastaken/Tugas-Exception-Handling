// Interface dan inheritence
public interface Pembayaran {
    double hitungTotalBayar();
}