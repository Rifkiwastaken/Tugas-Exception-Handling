import java.util.Scanner;

public class LoginSystem {

    private static final String USERNAME = "admin";
    private static final String PASSWORD = "password";
    private static final String CAPTCHA = "AbCdEf";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Login System ===");

        // Input username
        System.out.print("Enter username: ");
        String inputUsername = scanner.nextLine();

        // Input password
        System.out.print("Enter password: ");
        String inputPassword = scanner.nextLine();

        // Verify credentials
        if (verifyCredentials(inputUsername, inputPassword)) {
            // Login successful, check captcha
            System.out.println("Login successful!");
            System.out.print("Enter the captcha (case-insensitive): ");
            String inputCaptcha = scanner.nextLine();

            // Verify captcha
            if (verifyCaptcha(inputCaptcha)) {
                System.out.println("Captcha verification successful. Access granted!");
            } else {
                System.out.println("Captcha verification failed. Access denied!");
            }
        } else {
            System.out.println("Invalid username or password. Access denied!");
        }

        // Close the scanner
        scanner.close();
    }

    // Method to verify username and password
    private static boolean verifyCredentials(String username, String password) {
        return USERNAME.equals(username) && PASSWORD.equals(password);
    }

    // Method to verify captcha (case-insensitive)
    private static boolean verifyCaptcha(String captcha) {
        return CAPTCHA.equalsIgnoreCase(captcha);
    }
}